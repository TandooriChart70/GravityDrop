# Gravity Drop — iPhone gravity Home Screen simulator

**A free native iOS app that uses SpriteKit physics and your phone's motion sensors.**
It simulates 20 familiar app icons. Tap **Drop icons** or shake to release them; tilt your iPhone to change the direction of gravity, then tap icons to flick them. **Reset** restores the layout. There are no ads, accounts, tracking SDKs, or remote dependencies in the app.

> This is a simulated Home Screen **inside a separate app**. It cannot access or animate your real iOS Home Screen icons. SideStore cannot bypass that restriction.

## Instant browser preview

Open `GravityDrop-preview.html` on a PC to test the look and falling-icon physics immediately. The native `.ipa` project below is needed for reliable iPhone motion controls and a true standalone app. In mobile Safari, shake/tilt permission requires Safari to grant motion access, and an HTTPS-hosted page may be required; on-screen Drop and Reset work without it.

## Option A — build an IPA on GitHub (no Mac needed)

1. On a PC, unzip the `GravityDrop-project.zip` download.
2. Sign in to https://github.com and create a **new public repository**, e.g. `GravityDrop`. Leave the repository empty (no pre-created README/license).
3. Open PowerShell in the **unzipped GravityDrop folder** (this folder contains `project.yml`). Run:

   ```powershell
   git init
   git branch -M main
   git add .
   git commit -m "Gravity Drop for iPhone"
   git remote add origin https://github.com/YOUR_USERNAME/GravityDrop.git
   git push -u origin main
   ```

   Replace `YOUR_USERNAME` with your GitHub username. You may need to sign in through the browser when Git asks. If `git` is not installed, install Git for Windows from https://git-scm.com/download/win. You can also upload the **unzipped files and folders** using GitHub's **Add file → Upload files**, making sure `.github/workflows/build-ipa.yml` keeps its directory structure.
4. On GitHub, open your repository → **Actions** → **Build SideStore IPA** → **Run workflow**.
5. After the run succeeds, open the run details and download the **GravityDrop-SideStore-IPA** artifact. Unzip the artifact download to obtain `GravityDrop.ipa`.
6. Transfer `GravityDrop.ipa` to your iPhone (AirDrop, iCloud Drive, or Files). Open **SideStore → My Apps → +** and select the `.ipa`. Follow SideStore's signing prompts.

The IPA is **unsigned by design**. GitHub's macOS runner builds it and SideStore signs it. No paid Apple developer account or Mac is required for this method; SideStore itself must be set up and working. Free Apple ID provisioning limits still apply. Public GitHub Actions usage is subject to GitHub's current limits.

## Option B — build with a Mac

```bash
brew install xcodegen
xcodegen generate
open GravityDrop.xcodeproj
```

Select a physical iPhone target in Xcode, sign with your developer account, then run. For a SideStore-compatible unsigned IPA, use the same build commands in `.github/workflows/build-ipa.yml`.

## Customization

- `GravityDrop/GravityScene.swift`: simulated app names, colors, SF Symbol icons, and physics.
- `GravityDrop/GravityHomeView.swift`: interface, wallpaper, shake detection, tilt control.
- `GravityDrop/Assets.xcassets/AppIcon.appiconset/`: app icon.
- `project.yml`: app identifiers and iOS deployment target.

## Limitations / troubleshooting

- For shake/tilt, run on a physical iPhone (not the iOS Simulator). You can always use the on-screen **Drop icons** control.
- The app has no ability to enumerate installed apps or launch all apps by pretending to be the SpringBoard Home Screen.
- If a free Apple account's signing provision expires, refresh the app in SideStore.
- If compilation fails, check the detailed error in GitHub Actions build log. This project has been syntax-checked outside Xcode, but an iOS build on Apple's SDK has not been run here.

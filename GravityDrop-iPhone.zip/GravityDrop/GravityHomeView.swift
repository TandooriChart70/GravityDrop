import CoreMotion
import SpriteKit
import SwiftUI
import UIKit

final class GravityController: ObservableObject {
    @Published var dropped = false
    @Published var tiltEnabled = true
    @Published var motionSupported = true
    let scene = GravityScene(size: CGSize(width: 390, height: 844))
    private let motionManager = CMMotionManager()
    private var lastShake = Date.distantPast

    func start() {
        guard motionManager.isDeviceMotionAvailable else {
            motionSupported = false
            return
        }
        motionSupported = true
        guard !motionManager.isDeviceMotionActive else { return }
        motionManager.deviceMotionUpdateInterval = 1.0 / 35.0
        motionManager.startDeviceMotionUpdates(to: .main) { [weak self] sample, _ in
            guard let self, let sample else { return }
            self.scene.setTilt(x: sample.gravity.x, y: sample.gravity.y,
                               enabled: self.tiltEnabled)
            let force = sqrt(pow(sample.userAcceleration.x, 2) +
                             pow(sample.userAcceleration.y, 2) +
                             pow(sample.userAcceleration.z, 2))
            if force > 1.45, Date().timeIntervalSince(self.lastShake) > 0.75 {
                self.lastShake = Date()
                self.drop()
            }
        }
    }

    func stop() { motionManager.stopDeviceMotionUpdates() }

    func drop() {
        scene.dropIcons()
        dropped = true
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
    }

    func reset() {
        scene.arrangeIcons(animated: true)
        dropped = false
        UINotificationFeedbackGenerator().notificationOccurred(.success)
    }

    func toggleTilt() {
        tiltEnabled.toggle()
        if !tiltEnabled { scene.setTilt(x: 0, y: -1, enabled: false) }
        UISelectionFeedbackGenerator().selectionChanged()
    }
}

struct GravityCanvas: UIViewRepresentable {
    let scene: GravityScene

    func makeUIView(context: Context) -> SKView {
        let view = SKView(frame: .zero)
        view.backgroundColor = .clear
        view.isOpaque = false
        view.allowsTransparency = true
        view.ignoresSiblingOrder = true
        view.preferredFramesPerSecond = 60
        view.presentScene(scene)
        return view
    }

    func updateUIView(_ view: SKView, context: Context) {
        if view.scene !== scene { view.presentScene(scene) }
    }
}

struct GravityHomeView: View {
    @StateObject private var controller = GravityController()
    @State private var showInstructions = false

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                wallpaper

                // The fake dock stays put; its four icons fall independently.
                RoundedRectangle(cornerRadius: 34, style: .continuous)
                    .fill(.white.opacity(0.16))
                    .overlay {
                        RoundedRectangle(cornerRadius: 34, style: .continuous)
                            .strokeBorder(.white.opacity(0.20), lineWidth: 1)
                    }
                    .frame(width: geometry.size.width - 38, height: 100)
                    .position(x: geometry.size.width / 2, y: geometry.size.height - max(155, min(182, geometry.size.height * 0.205)))

                GravityCanvas(scene: controller.scene)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)

                VStack(spacing: 0) {
                    header
                        .padding(.horizontal, 28)
                        .padding(.top, 64)
                    Spacer(minLength: 0)
                    controls
                        .padding(.horizontal, 25)
                        .padding(.bottom, 28)
                }
            }
            .frame(width: geometry.size.width, height: geometry.size.height)
        }
        .ignoresSafeArea()
        .onAppear { controller.start() }
        .onDisappear { controller.stop() }
        .alert("How it works", isPresented: $showInstructions) {
            Button("Got it", role: .cancel) { }
        } message: {
            Text("Tap DROP or shake your phone to release the icons. Tilt to steer them. Tap an icon to flick it upward. RESET puts them back. This is a simulated Home Screen — your real apps stay unchanged.")
        }
    }

    private var wallpaper: some View {
        ZStack {
            LinearGradient(colors: [Color(red: 0.07, green: 0.08, blue: 0.21),
                                    Color(red: 0.18, green: 0.13, blue: 0.39),
                                    Color(red: 0.14, green: 0.29, blue: 0.43)],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
            Circle()
                .fill(Color(red: 0.59, green: 0.33, blue: 1.0).opacity(0.45))
                .frame(width: 350, height: 350)
                .blur(radius: 90)
                .offset(x: 130, y: -230)
            Circle()
                .fill(Color(red: 0.1, green: 0.68, blue: 0.95).opacity(0.27))
                .frame(width: 360, height: 360)
                .blur(radius: 85)
                .offset(x: -160, y: 280)
        }
        .ignoresSafeArea()
    }

    private var header: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 6) {
                Text(Date.now.formatted(.dateTime.weekday(.wide).month(.wide).day()))
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white.opacity(0.74))
                Text("Gravity Drop")
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                    .tracking(-1.2)
                    .foregroundStyle(.white)
                HStack(spacing: 5) {
                    Circle()
                        .fill(controller.dropped ? .mint : .white.opacity(0.65))
                        .frame(width: 7, height: 7)
                    Text(controller.dropped ? "ICON CHAOS ACTIVE" : "READY TO FALL")
                        .font(.system(size: 10, weight: .heavy, design: .rounded))
                        .tracking(1.3)
                        .foregroundStyle(.white.opacity(0.75))
                }
                .padding(.top, 4)
            }
            Spacer()
            Button { showInstructions = true } label: {
                Image(systemName: "questionmark")
                    .font(.system(size: 14, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 36, height: 36)
                    .background(.white.opacity(0.14), in: Circle())
            }
            .accessibilityLabel("Instructions")
        }
    }

    private var controls: some View {
        VStack(spacing: 10) {
            HStack(spacing: 8) {
                Image(systemName: "iphone.radiowaves.left.and.right")
                Text(controller.motionSupported ? "SHAKE TO DROP  ·  TILT TO STEER" : "TAP DROP TO START")
            }
            .font(.system(size: 10.5, weight: .bold, design: .rounded))
            .tracking(1.1)
            .foregroundStyle(.white.opacity(0.78))
            .padding(.bottom, 1)

            HStack(spacing: 12) {
                Button { controller.reset() } label: {
                    Label("Reset", systemImage: "arrow.counterclockwise")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(GlassButtonStyle(filled: false))

                Button { controller.drop() } label: {
                    Label(controller.dropped ? "Shake up" : "Drop icons", systemImage: "arrow.down.right.and.arrow.up.left")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(GlassButtonStyle(filled: true))
            }
            Button { controller.toggleTilt() } label: {
                HStack(spacing: 6) {
                    Image(systemName: controller.tiltEnabled ? "gyroscope" : "gyroscope")
                    Text("TILT CONTROL: \(controller.tiltEnabled ? "ON" : "OFF")")
                    Image(systemName: "chevron.up.chevron.down")
                        .font(.system(size: 9))
                }
                .font(.system(size: 10, weight: .bold, design: .rounded))
                .tracking(1)
                .foregroundStyle(.white.opacity(0.75))
                .padding(.vertical, 5)
            }
        }
    }
}

private struct GlassButtonStyle: ButtonStyle {
    let filled: Bool
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(size: 14, weight: .bold, design: .rounded))
            .foregroundStyle(.white)
            .padding(.vertical, 15)
            .background {
                RoundedRectangle(cornerRadius: 17, style: .continuous)
                    .fill(filled ? Color(red: 0.54, green: 0.37, blue: 0.99) : Color.white.opacity(0.18))
            }
            .overlay {
                RoundedRectangle(cornerRadius: 17, style: .continuous)
                    .strokeBorder(.white.opacity(filled ? 0.27 : 0.16), lineWidth: 1)
            }
            .scaleEffect(configuration.isPressed ? 0.97 : 1)
            .animation(.easeOut(duration: 0.13), value: configuration.isPressed)
    }
}

import Foundation
import SpriteKit
import UIKit

// A self-contained, simulated home screen. iOS does not allow apps to read or move
// the icons on the user's actual Home Screen.
struct FauxApp {
    let title: String
    let symbol: String
    let top: UIColor
    let bottom: UIColor
    let symbolColor: UIColor

    init(_ title: String, _ symbol: String, _ top: UInt, _ bottom: UInt, symbolColor: UIColor = .white) {
        self.title = title
        self.symbol = symbol
        self.top = UIColor(rgb: top)
        self.bottom = UIColor(rgb: bottom)
        self.symbolColor = symbolColor
    }
}

private extension UIColor {
    convenience init(rgb: UInt) {
        self.init(red: CGFloat((rgb >> 16) & 0xff) / 255,
                  green: CGFloat((rgb >> 8) & 0xff) / 255,
                  blue: CGFloat(rgb & 0xff) / 255, alpha: 1)
    }
}

final class GravityScene: SKScene {
    // The last four icons live in the translucent dock when initially arranged.
    private let applications: [FauxApp] = [
        FauxApp("Photos", "camera.filters", 0xFFEFA7, 0xEE6AA7),
        FauxApp("Camera", "camera.fill", 0x727B91, 0x242B3A),
        FauxApp("Weather", "cloud.sun.fill", 0x76CEFF, 0x3977E9),
        FauxApp("Maps", "map.fill", 0x78D48A, 0x299EB9),
        FauxApp("Calendar", "calendar", 0xFF7676, 0xE63C52),
        FauxApp("Clock", "clock.fill", 0x42495B, 0x161922),
        FauxApp("Notes", "note.text", 0xFFE47B, 0xEFB243),
        FauxApp("Settings", "gearshape.fill", 0xAAB6C7, 0x707D91),
        FauxApp("Music", "music.note", 0xFE83A3, 0xE83965),
        FauxApp("Games", "gamecontroller.fill", 0xB48BFE, 0x694AD9),
        FauxApp("Health", "heart.fill", 0xFFB7C6, 0xEF5679),
        FauxApp("Wallet", "creditcard.fill", 0x697C8E, 0x253447),
        FauxApp("Books", "book.closed.fill", 0xF0B36B, 0xDB7336),
        FauxApp("Files", "folder.fill", 0x58A9FC, 0x2169D8),
        FauxApp("TV", "play.rectangle.fill", 0x495267, 0x151A28),
        FauxApp("Home", "house.fill", 0x93B6FA, 0x5365C9),
        FauxApp("Phone", "phone.fill", 0x64E68B, 0x12A554),
        FauxApp("Safari", "safari.fill", 0x61D8FA, 0x2977E9),
        FauxApp("Messages", "message.fill", 0x87EB86, 0x22B65A),
        FauxApp("Mail", "envelope.fill", 0x58C2FF, 0x3066EF)
    ]

    private var iconNodes: [SKNode] = []
    private var iconSize: CGFloat = 62
    private(set) var isDropped = false
    private var lastSceneSize: CGSize = .zero

    override init(size: CGSize) {
        super.init(size: size)
        scaleMode = .resizeFill
        backgroundColor = .clear
        anchorPoint = CGPoint(x: 0, y: 0)
        physicsWorld.gravity = CGVector(dx: 0, dy: -20)
        setupIcons()
        arrangeIcons(animated: false)
    }

    required init?(coder aDecoder: NSCoder) { fatalError("Use init(size:)") }

    override func didChangeSize(_ oldSize: CGSize) {
        super.didChangeSize(oldSize)
        guard size.width > 0, size.height > 0,
              abs(size.width - lastSceneSize.width) > 1 || abs(size.height - lastSceneSize.height) > 1 else { return }
        arrangeIcons(animated: false)
    }

    private func setupIcons() {
        for (index, app) in applications.enumerated() {
            let item = SKNode()
            item.name = "app-\(index)"
            item.zPosition = CGFloat(index + 5)
            item.isUserInteractionEnabled = false
            addChild(item)
            iconNodes.append(item)
        }
    }

    private func renderIcon(_ app: FauxApp, side: CGFloat) -> UIImage {
        let renderer = UIGraphicsImageRenderer(size: CGSize(width: side * 3, height: side * 3))
        return renderer.image { context in
            let graphics = context.cgContext
            graphics.scaleBy(x: 3, y: 3)
            let bounds = CGRect(x: 0, y: 0, width: side, height: side)
            let clip = UIBezierPath(roundedRect: bounds, cornerRadius: side * 0.225)
            graphics.addPath(clip.cgPath)
            graphics.clip()
            let colors = [app.top.cgColor, app.bottom.cgColor] as CFArray
            if let gradient = CGGradient(colorsSpace: CGColorSpaceCreateDeviceRGB(), colors: colors, locations: [0, 1]) {
                graphics.drawLinearGradient(gradient,
                                            start: CGPoint(x: 0, y: 0),
                                            end: CGPoint(x: side, y: side), options: [])
            }
            UIColor.white.withAlphaComponent(0.13).setFill()
            UIBezierPath(ovalIn: CGRect(x: -side * 0.32, y: -side * 0.63,
                                        width: side * 1.25, height: side * 1.18)).fill()

            let config = UIImage.SymbolConfiguration(pointSize: side * 0.43, weight: .semibold)
            if let symbol = UIImage(systemName: app.symbol, withConfiguration: config)?
                .withTintColor(app.symbolColor, renderingMode: .alwaysOriginal) {
                let imageSize = symbol.size
                symbol.draw(in: CGRect(x: (side - imageSize.width) / 2,
                                       y: (side - imageSize.height) / 2,
                                       width: imageSize.width, height: imageSize.height))
            }
        }
    }

    private func configureGraphic(_ item: SKNode, for app: FauxApp) {
        item.removeAllChildren()
        let shadow = SKShapeNode(rectOf: CGSize(width: iconSize, height: iconSize),
                                 cornerRadius: iconSize * 0.23)
        shadow.fillColor = UIColor.black.withAlphaComponent(0.25)
        shadow.strokeColor = .clear
        shadow.position.y = -3
        shadow.zPosition = -1
        item.addChild(shadow)

        let icon = SKSpriteNode(texture: SKTexture(image: renderIcon(app, side: iconSize)))
        icon.size = CGSize(width: iconSize, height: iconSize)
        item.addChild(icon)

        let labelShadow = SKLabelNode(fontNamed: "HelveticaNeue-Medium")
        labelShadow.text = app.title
        labelShadow.fontSize = 11.1
        labelShadow.fontColor = UIColor.black.withAlphaComponent(0.70)
        labelShadow.horizontalAlignmentMode = .center
        labelShadow.verticalAlignmentMode = .center
        labelShadow.position = CGPoint(x: 0.6, y: -iconSize / 2 - 17.5)
        labelShadow.zPosition = -1
        item.addChild(labelShadow)

        let label = SKLabelNode(fontNamed: "HelveticaNeue-Medium")
        label.text = app.title
        label.fontSize = 11.1
        label.fontColor = .white
        label.horizontalAlignmentMode = .center
        label.verticalAlignmentMode = .center
        label.position = CGPoint(x: 0, y: -iconSize / 2 - 17)
        item.addChild(label)

        let body = SKPhysicsBody(rectangleOf: CGSize(width: iconSize, height: iconSize + 15),
                                 center: CGPoint(x: 0, y: -7))
        body.isDynamic = false
        body.affectedByGravity = true
        body.allowsRotation = true
        body.restitution = 0.59
        body.friction = 0.51
        body.linearDamping = 0.42
        body.angularDamping = 1.05
        body.categoryBitMask = 2
        body.collisionBitMask = 1 | 2
        item.physicsBody = body
    }

    private func homePosition(for index: Int) -> CGPoint {
        let availableWidth = min(size.width - 65, 330)
        let firstX = (size.width - availableWidth) / 2
        if index >= 16 {
            let dockWidth = min(size.width - 134, 255)
            return CGPoint(x: (size.width - dockWidth) / 2 + CGFloat(index - 16) * (dockWidth / 3),
                           y: max(155, min(182, size.height * 0.205)))
        }
        let firstRowY = size.height - max(184, size.height * 0.25)
        let rowPitch = min(103, max(74, (size.height - 350) / 4.5))
        return CGPoint(x: firstX + CGFloat(index % 4) * (availableWidth / 3),
                       y: firstRowY - CGFloat(index / 4) * rowPitch)
    }

    func arrangeIcons(animated: Bool) {
        guard size.width > 50 && size.height > 150 else { return }
        lastSceneSize = size
        iconSize = min(65, max(48, (size.width - 87) / 4.65))
        physicsBody = SKPhysicsBody(edgeLoopFrom: CGRect(x: 9, y: 99,
                           width: max(50, size.width - 18), height: max(100, size.height - 218)))
        physicsBody?.categoryBitMask = 1
        physicsBody?.collisionBitMask = 2
        physicsBody?.friction = 0.7
        physicsBody?.restitution = 0.46

        isDropped = false
        for (index, item) in iconNodes.enumerated() {
            item.removeAllActions()
            item.physicsBody = nil
            configureGraphic(item, for: applications[index])
            let target = homePosition(for: index)
            item.zRotation = 0
            if animated {
                item.run(SKAction.move(to: target, duration: 0.29))
            } else {
                item.position = target
            }
        }
    }

    func dropIcons() {
        if !isDropped {
            isDropped = true
            for item in iconNodes {
                item.removeAllActions()
                item.physicsBody?.isDynamic = true
                item.physicsBody?.velocity = CGVector(dx: CGFloat.random(in: -105...105),
                                                       dy: CGFloat.random(in: 45...145))
                item.physicsBody?.angularVelocity = CGFloat.random(in: -2.4...2.4)
            }
        } else {
            scatterIcons()
        }
    }

    func scatterIcons() {
        guard isDropped else { dropIcons(); return }
        for item in iconNodes {
            item.physicsBody?.velocity = CGVector(dx: CGFloat.random(in: -185...185),
                                                   dy: CGFloat.random(in: 80...280))
            item.physicsBody?.angularVelocity = CGFloat.random(in: -5...5)
        }
    }

    func setTilt(x: Double, y: Double, enabled: Bool) {
        if enabled {
            // In portrait, Core Motion X points right and Y points toward the top.
            physicsWorld.gravity = CGVector(dx: CGFloat(x * 32), dy: CGFloat(y * 31 - 4))
        } else {
            physicsWorld.gravity = CGVector(dx: 0, dy: -24)
        }
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        let hit = nodes(at: location)
        var tapped: SKNode?
        for node in hit {
            var candidate: SKNode? = node
            while let current = candidate {
                if let name = current.name, name.hasPrefix("app-") {
                    tapped = current
                    break
                }
                candidate = current.parent
            }
            if tapped != nil { break }
        }
        guard let icon = tapped else { return }
        if !isDropped { dropIcons() }
        icon.physicsBody?.velocity = CGVector(dx: CGFloat.random(in: -150...150), dy: 240)
        icon.physicsBody?.angularVelocity = CGFloat.random(in: -5...5)
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
    }
}

import SwiftUI

@main
struct GravityDropApp: App {
    var body: some Scene {
        WindowGroup {
            GravityHomeView()
                .preferredColorScheme(.dark)
        }
    }
}
